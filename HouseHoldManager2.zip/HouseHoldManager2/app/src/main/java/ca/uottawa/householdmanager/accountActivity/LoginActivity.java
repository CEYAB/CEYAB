package ca.uottawa.householdmanager.accountActivity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import ca.uottawa.householdmanager.R;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);
    }
}
